import React from 'react';
import MainPageLayout from '../components/MainPageLayout';

const Home = () => {
  return <MainPageLayout>this is home</MainPageLayout>;
};

export default Home;
