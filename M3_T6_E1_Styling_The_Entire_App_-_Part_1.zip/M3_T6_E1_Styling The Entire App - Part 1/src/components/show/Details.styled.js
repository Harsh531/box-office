import styled from 'styled-components';

export const DetailsWrapper = styled.div`
  p {
    margin: 5px 0;

    span {
      font-weight: bold;
    }
  }
`;
