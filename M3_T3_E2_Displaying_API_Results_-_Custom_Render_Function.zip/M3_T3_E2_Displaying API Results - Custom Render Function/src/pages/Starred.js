import React from 'react';
import MainPageLayout from '../components/MainPageLayout';

const Starred = () => {
  return <MainPageLayout>this is starred</MainPageLayout>;
};

export default Starred;
